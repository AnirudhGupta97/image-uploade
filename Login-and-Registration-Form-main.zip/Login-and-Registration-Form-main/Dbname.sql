

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


CREATE TABLE `users` (
  `username` varchar(1000) NOT NULL,
  `Email` varchar(1000) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



INSERT INTO `users` (`username`, `Email`, `password`) VALUES
('admin', 'admin@gmail.com', 'admin');



ALTER TABLE `users`
  ADD UNIQUE KEY `username` (`username`) USING HASH;
COMMIT;

CREATE TABLE `uploade` (
  `username` varchar(1000) NOT NULL,
  `type` varchar(1000) NOT NULL,
  `image` BLOB NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

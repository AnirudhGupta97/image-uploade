<?php
session_start();
if(!isset($_SESSION["username"])){
    header("Location: index.php"); 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="indexstyle.css">
    
    </head>


<body>
<?php
include_once('db.php');
require('db.php');
error_reporting(0);
$uploadOk = 1;
$flag=0;
$username=$_SESSION["username"];
if (isset($_POST['submit'])) {

    $imageFileType = pathinfo($_FILES["uploadfile"]["name"], PATHINFO_EXTENSION);

    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
      echo "<div class='form'><h3>Sorry, only JPG, JPEG, PNG & GIF files are allowed.</h3> </div>";
      $uploadOk = 0;
    }

    
    
   if ($uploadOk==1)
   {
    $filetempname=$_FILES["uploadfile"]["tmp_name"];
    $filename=$_FILES["uploadfile"]["name"];
    $filder='uploadimage/';
    move_uploaded_file($filetempname,$filder.$filename);

     $type=$_POST['type'];
     if($type=="Portrait image type")
     {$flag=0;}
     else
     {$flag=1;}
     $query = "INSERT INTO `uploade` (`username`, `types`, `image`) VALUES ('$username', '$type', '$filename');";
     $result = mysqli_query($conn,$query) ;
     
        
        if($result)
        {
            echo "<div class='form'><h3>Image upload</h3></div>";
        }
        else
         {echo " <div class='form'><h3>Image not upload</h3> </div>";}
     
   }
  }
  
?>
<div  >
        <img src="photo.jfif" class = "image"  >
    </div>
    <div class ="login">
<div class="form">
<h1>UPLOAD IMAGE!!</h1>
<h1>Select image to upload:<h1>
<form action="" method="post"  enctype="multipart/form-data">
<label for="type">Choose the type:</label>
</br></br>
  <select id="type" name="type" size="">
    <option value="Portrait image type">Portrait image type</option>
    <option value="Landscape Image Type">Landscape Image Type</option>
  </select><br><br>
<input type="file" name="uploadfile" id="uploadfile" accept="image/*" />

  <input type="submit" value="Upload Image" name="submit"/>
  <input type="submit" value="Show image" name="showinage"/>
<br>
</form>
</div>
</div>
</body>

</html>
<?php

if (isset($_POST['showinage']))
  {
  
    $result1 = mysqli_query($conn,"SELECT * FROM uploade where( username='$username' &&  types='Portrait image type' )") ;
    $result2 = mysqli_query($conn,"SELECT * FROM uploade where( username='$username' &&  types='Landscape Image Type')") ;
     while( ($temp1=mysqli_fetch_array($result1) ) &&  ($temp2=mysqli_fetch_array($result2) ) )
     {
       
      if($flag==0)
      {
        ?>
           <tr>
           <td><img src="./uploadimage/<?php echo $temp1['image']; ?>" width="100" hight="100"></td>
           <td><img src="./uploadimage/<?php echo $temp1['image']; ?>" width="100" hight="100"></td>
           <br>
           <td><img src="./uploadimage/<?php echo $temp2['image']; ?>" width="100" hight="100"></td>
           </tr>
           <br>
           <?php
      }
      else
      {
        ?>
        <tr>
          <td><img src="./uploadimage/<?php echo $temp2['image']; ?>" width="100" hight="100"></td>
          <br>
          <br>
           <td><img src="./uploadimage/<?php echo $temp1['image']; ?>" width="100" hight="100"></td>
           
           <td><img src="./uploadimage/<?php echo $temp1['image']; ?>" width="100" hight="100"></td>
        </tr>
        <br>
        <?php
      }
    }
  }
?>